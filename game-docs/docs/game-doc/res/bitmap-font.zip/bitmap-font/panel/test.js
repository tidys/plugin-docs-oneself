function hello(a, b, c) {
    console.log(a);
}

hello(1, 23, 4);