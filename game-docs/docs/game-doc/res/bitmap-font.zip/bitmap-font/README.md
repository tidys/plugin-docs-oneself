# 项目说明文档

已经迁徙到[github](https://github.com/tidys/CocosCreatorPlugins/blob/master/doc/bitmap-font/README.md)