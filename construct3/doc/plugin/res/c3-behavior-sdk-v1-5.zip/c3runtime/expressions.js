"use strict";

{
	self.C3.Behaviors.MyCompany_MyBehavior.Exps =
	{
		MyExpression()
		{
			return 1337;
		}
	};
}