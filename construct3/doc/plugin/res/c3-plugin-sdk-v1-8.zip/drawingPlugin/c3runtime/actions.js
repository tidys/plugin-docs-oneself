"use strict";

{
	self.C3.Plugins.MyCompany_DrawingPlugin.Acts =
	{
		Alert()
		{
			alert("Test property = " + this._GetTestProperty());
		}
	};
}