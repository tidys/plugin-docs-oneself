"use strict";

{
	self.C3.Plugins.MyCompany_DrawingPlugin.Exps =
	{
		Double(number)
		{
			return number * 2;
		}
	};
	
}