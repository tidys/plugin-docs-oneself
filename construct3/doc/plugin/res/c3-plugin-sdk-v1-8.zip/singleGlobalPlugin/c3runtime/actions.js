"use strict";

{
	self.C3.Plugins.MyCompany_SingleGlobal.Acts =
	{
		Alert()
		{
			alert("Test property = " + this._GetTestProperty());
		}
	};
}