"use strict";

{
	self.C3.Plugins.MyCompany_SingleGlobal.Exps =
	{
		Double(number)
		{
			return number * 2;
		}
	};
}