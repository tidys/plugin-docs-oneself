"use strict";

{
	self.C3.Plugins.MyCompany_TextPlugin.Acts =
	{
		Alert()
		{
			alert("Hello world");
		}
	};
}