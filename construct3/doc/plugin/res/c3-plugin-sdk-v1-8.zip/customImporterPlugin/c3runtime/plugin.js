"use strict";

{
	const C3 = self.C3;

	C3.Plugins.MyCompany_CustomImporter = class CustomImporterPlugin extends C3.SDKPluginBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}