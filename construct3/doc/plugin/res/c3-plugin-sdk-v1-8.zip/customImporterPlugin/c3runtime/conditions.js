"use strict";

{
	self.C3.Plugins.MyCompany_CustomImporter.Cnds =
	{
		IsLargeNumber(number)
		{
			return number > 100;
		}
	};
}