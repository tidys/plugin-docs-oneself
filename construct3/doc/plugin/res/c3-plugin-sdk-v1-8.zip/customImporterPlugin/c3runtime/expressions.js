"use strict";

{
	self.C3.Plugins.MyCompany_CustomImporter.Exps =
	{
		Double(number)
		{
			return number * 2;
		}
	};
}