"use strict";

{
	self.C3.Plugins.MyCompany_DOMPlugin.Acts =
	{
		SetText(text)
		{
			this._SetText(text);
		}
	};
}