"use strict";

{
	self.C3.Plugins.MyCompany_DOMPlugin.Cnds =
	{
		OnClick()
		{
			return true;
		}
	};
}